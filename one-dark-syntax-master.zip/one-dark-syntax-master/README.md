## One Dark Syntax theme

### This package is now a part of the [core Atom repository](https://github.com/atom/atom/tree/master/packages/one-dark-syntax), please direct all issues and pull requests there in the future!

![one-dark-syntax](https://user-images.githubusercontent.com/238929/40553597-5f741518-6000-11e8-9068-70dfc5008b54.png)

> The font used in the screenshot is [Fira Mono](https://github.com/mozilla/Fira).

There is also a matching [UI theme](https://atom.io/themes/one-dark-ui).

### Install

This theme is installed by default with Atom and can be activated by going to the __Settings > Themes__ section and selecting it from the __Syntax Themes__ drop-down menu.
